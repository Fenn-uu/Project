# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 17:05:44 2021

@author: ferde233
"""

from .mammals import Mammals
from .birds import Birds
from .fish import Fish
