#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  2 16:43:01 2021

@author: fernand
"""

from classroom import Student

me = Student('Fernand', 'Denoel', 'physics') 
me.printNameSubject() 
